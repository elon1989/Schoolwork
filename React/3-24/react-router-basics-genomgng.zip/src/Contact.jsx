const Contact = () => {
  return (
    <div>
      <h2>This is the contact page</h2>
    </div>
  );
};

export default Contact;
