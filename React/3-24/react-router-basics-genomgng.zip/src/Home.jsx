const Home = () => {
  return (
    <div>
      <h2>This is the Homepage</h2>
    </div>
  );
};

export default Home;
